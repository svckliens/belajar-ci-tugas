<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

ini halaman profile
<?= $this->endSection() ?>