<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

ini halaman fak
<?= $this->endSection() ?>